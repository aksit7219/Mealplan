import React from 'react'
export const SalesNmarket = () => {

  return (
    <div>Sales Market</div>
  )
}

export default SalesNmarket;
